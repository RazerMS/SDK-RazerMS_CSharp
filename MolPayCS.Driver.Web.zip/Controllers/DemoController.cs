﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MolPayCS.Driver.Web.Models;
using MolPayCS.Core;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MolPayCS.Driver.Web.Controllers
{
    public class DemoController : Controller
    {
        // GET: /<controller>/
        public IActionResult Hosted()
        {
            Payment paymentObject = new Payment();

            paymentObject.Vkey = "10592b2e945cfebb925b6f7bf8cd889f";            // Replace ​xxxxxxxxxx with your MOLPay Verify Key
            paymentObject.Domain = "molpay";                                    // Replace ​XXXXXX with your MOLPay Merchant ID
            paymentObject.Amount = "99.00";                                    // 2 decimal points numeric value
            paymentObject.Orderid = "OP-00593";                               // alphanumeric, 32 characters
            paymentObject.Bill_name = "Shazlee Rosli";
            paymentObject.Bill_email = "shazlee69@msn.com";
            paymentObject.Bill_desc = "Renewal Razer Merchant";
            paymentObject.Currency = "MYR";                                     // 2 or 3 chars (ISO-4217) currency code
            paymentObject.Country = "MY";                                       // 2 chars of ISO-3166 country code
            paymentObject.Returnurl = "http://exampleurl";                      // Desired returned page after payment page
            paymentObject.TIDs = "108882553|109175019";                         // `pipe` separated TID
            paymentObject.OID = "OP-00593";
            paymentObject.OIDs = "OP-00593|JKL Studio Sdn Bhd";                 // `pipe` separated OID
            paymentObject.Url = "https://your.url/here";                        // Url for requery callback
            paymentObject.Delimiter = "|";
            paymentObject.TxID = "108882553";

            paymentObject.TypeID = "production";

            ViewBag.pmtObject = paymentObject;

            return View();
        }

        public IActionResult Seamless()
        {
            return View();
        }

        public IActionResult SeamlessProcess()
        {
            Seamlesspayment paymentObject = new Seamlesspayment();
            paymentObject.Merchantid = "molpay";                        //Replace xxx Merchant login username provided by MOLPay
            paymentObject.Vkey = "10592b2e945cfebb925b6f7bf8cd889f";    //Replace xxx with your verify key
            paymentObject.Orderid = "OP-00593";                         //Replace xxx with Bill / Invoice no. provided by merchant
            paymentObject.Country = "MY";                               //Buyer country
            paymentObject.ReturnUrl = "https://your.url/here";          //Replace xxx with your return URL
            paymentObject.CancelUrl = "https://your.url/here";          //Replace xxx with URL to redirect when the payment is time out. Mandatory when timer is enable.
            paymentObject.Failureurl = "https://your.url/here";         //Replace xxx with URL to redirect when transcation fail

            return Json(
                paymentObject.ProcessRequest()
            );
        }
    }
}
