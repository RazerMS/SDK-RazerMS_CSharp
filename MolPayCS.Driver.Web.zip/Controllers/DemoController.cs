﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MolPayCS.Driver.Web.Models;
using MolPayCS.Core;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MolPayCS.Driver.Web.Controllers
{
    public class DemoController : Controller
    {
        // GET: /<controller>/
        public IActionResult Hosted()
        {
            Payment paymentObject = new Payment();

            paymentObject.Vkey = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";            // Replace ​xxxxxxxxxx with your MOLPay Verify Key
            paymentObject.Domain = "XXXXXX";                                    // Replace ​XXXXXX with your MOLPay Merchant ID
            paymentObject.Amount = "99.00";                                     // 2 decimal points numeric value
            paymentObject.Orderid = "XXXXXXXX";                                 // alphanumeric, 32 characters
            paymentObject.Bill_name = "XXXXXXXXXXXXX";
            paymentObject.Bill_email = "XXXXXXXXXXX@XXXX.XX";
            paymentObject.Bill_desc = "DESCRIPTION HERE";
            paymentObject.Currency = "MYR";                                     // 2 or 3 chars (ISO-4217) currency code
            paymentObject.Country = "MY";                                       // 2 chars of ISO-3166 country code
            paymentObject.Returnurl = "http://exampleurl";                      // Desired returned page after payment page
            paymentObject.TIDs = "<TID1>|<TID2>|<TID3>";                        // `pipe` separated TID
            paymentObject.OID = "XXXXXXXX";
            paymentObject.OIDs = "XXXXXXXX|XXXXXXXY";                           // `pipe` separated OID
            paymentObject.Url = "https://your.url/here";                        // Url for requery callback
            paymentObject.Delimiter = "|";
            paymentObject.TxID = "XXXXXXXXX";

            paymentObject.TypeID = "production";

            ViewBag.pmtObject = paymentObject;

            return View();
        }

        public IActionResult Seamless()
        {
            return View();
        }

        public IActionResult SeamlessProcess()
        {
            Seamlesspayment paymentObject = new Seamlesspayment();
            paymentObject.Merchantid = "xxxxxx";                        //Replace xxx Merchant login username provided by MOLPay
            paymentObject.Vkey = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx ";    //Replace xxx with your verify key
            paymentObject.Orderid = "xxxxxxxx";                         //Replace xxx with Bill / Invoice no. provided by merchant
            paymentObject.Country = "MY";                               //Buyer country
            paymentObject.ReturnUrl = "https://your.url/here";          //Replace xxx with your return URL
            paymentObject.CancelUrl = "https://your.url/here";          //Replace xxx with URL to redirect when the payment is time out. Mandatory when timer is enable.
            paymentObject.Failureurl = "https://your.url/here";         //Replace xxx with URL to redirect when transcation fail

            return Json(
                paymentObject.ProcessRequest()
            );
        }
    }
}
